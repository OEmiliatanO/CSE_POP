#ifndef __MYDEF_H__
#define __MYDEF_H__
typedef char* ptr_to_char;
typedef short* ptr_to_short;
typedef int* ptr_to_int;
typedef long* ptr_to_long;
typedef float* ptr_to_float;
typedef double* ptr_to_double;
#endif
